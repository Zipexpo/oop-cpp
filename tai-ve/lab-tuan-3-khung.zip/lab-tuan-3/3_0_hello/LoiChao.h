// LoiChao.h — KHAI BAO: cho biet "co nhung ham nao, nhan gi, tra ve gi". Khong viet than ham o day.
#ifndef LOICHAO_H
#define LOICHAO_H

#include <string>

void chaoBanDoc(const std::string& ten);

#endif
