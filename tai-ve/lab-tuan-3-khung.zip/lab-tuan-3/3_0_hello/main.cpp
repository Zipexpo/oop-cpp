// main.cpp — DUNG: chi can #include "LoiChao.h" la goi duoc ham, khong can biet than ham nam o dau.
#include "LoiChao.h"

int main() {
    chaoBanDoc("Nguyen Van An");
    return 0;
}
