// LoiChao.cpp — DINH NGHIA: viet than cua cac ham da khai bao trong LoiChao.h.
#include <iostream>
#include "LoiChao.h"

void chaoBanDoc(const std::string& ten) {
    std::cout << "Xin chao " << ten << "! Chuc ban hoc tot mon OOP." << std::endl;
}
