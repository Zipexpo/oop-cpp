// Bai 3.4 — Con tro va mang dong.
#include <iostream>
using namespace std;

// Nguyen mau bat buoc. Ben trong ham phai truy cap bang *(a + i), khong dung a[i].
int tongTrang(int* a, int n);

int main() {
    // TODO 1: nhap so cuon sach n
    // TODO 2: cap phat dong mot mang int co n phan tu
    // TODO 3: nhap so trang tung cuon vao mang
    // TODO 4: in tong so trang (goi tongTrang)
    // TODO 5: giai phong vung nho vua cap phat

    return 0;
}

int tongTrang(int* a, int n) {
    // TODO: cong don so trang bang *(a + i)
    return 0;
}
