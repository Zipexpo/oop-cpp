// Bai 3.1 — The ban doc. Doc de tren trang lab truoc khi viet.
#include <iostream>
#include <string>
using namespace std;

int main() {
    string hoTen;

    // TODO 1: in loi nhac "Nhap ho ten ban doc: "
    // TODO 2: nhap CA ho va ten (co khoang trang) vao hoTen
    // TODO 3: in hai dong cua the muon, dung tung ky tu nhu ket qua mau

    return 0;
}
