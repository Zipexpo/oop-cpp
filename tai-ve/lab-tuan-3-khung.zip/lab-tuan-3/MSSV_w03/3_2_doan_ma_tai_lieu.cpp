// Bai 3.2 — Doan ma tai lieu.
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    // TODO 1: khoi tao bo sinh so ngau nhien (chi goi MOT lan, truoc vong lap)
    // TODO 2: tao ma bi mat trong khoang 1 den 100
    // TODO 3: in cau mo dau
    // TODO 4: do ... while: nhap ma doan, dem so lan, in goi y hoac cau chuc mung

    return 0;
}
