// Bai 3.5 — Sap xep ma tai lieu, hoan doi bang con tro.
#include <iostream>
using namespace std;

// Bat buoc: Bubble Sort phai goi ham nay va truyen DIA CHI cua hai phan tu.
void hoanDoi(int* a, int* b) {
    // TODO: doi cho hai gia tri nam tai hai dia chi a va b
}

int main() {
    // Du lieu thu: 305 118 947 220 116 673
    // TODO 1: khai bao mang ma voi du lieu tren, tinh so phan tu n
    // TODO 2: in mang truoc khi sap xep
    // TODO 3: Bubble Sort tang dan, doi cho bang hoanDoi(...)
    // TODO 4: in mang sau khi sap xep

    return 0;
}
