// Bai 3.6 — Tim kiem nhi phan.
#include <iostream>
using namespace std;

// Tra ve vi tri cua 'can' trong ma[trai..phai]; khong co thi tra ve -1.
// Chi dung duoc khi mang da sap xep tang dan.
int timNhiPhan(int* ma, int trai, int phai, int can) {
    // TODO: lap khi doan [trai, phai] con phan tu; so voi phan tu o giua; thu hep sang trai hoac phai
    return -1;
}

int main() {
    // Du lieu: ket qua da sap xep cua bai 3.5 — 116 118 220 305 673 947
    // TODO 1: khai bao mang ma voi du lieu tren, tinh so phan tu n
    // TODO 2: nhap ma can tim
    // TODO 3: goi timNhiPhan, in "Tim thay ..." hoac "Khong co ..." dung nhu ket qua mau

    return 0;
}
