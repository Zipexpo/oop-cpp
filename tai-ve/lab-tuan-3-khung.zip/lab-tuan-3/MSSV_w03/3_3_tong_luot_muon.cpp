// Bai 3.3 — Thong ke luot muon bang ham.
#include <iostream>
using namespace std;

// Nguyen mau bat buoc (de bai cho san): khai bao TRUOC main.
int themLuot(int tong, int them);

int main() {
    // TODO 1: nhap so ngay n
    // TODO 2: vong lap nhap so luot muon tung ngay, cong don BANG ham themLuot
    // TODO 3: in tong so luot muon

    return 0;
}

// Dinh nghia dat SAU main.
int themLuot(int tong, int them) {
    // TODO: tra ve tong moi
    return 0;
}
