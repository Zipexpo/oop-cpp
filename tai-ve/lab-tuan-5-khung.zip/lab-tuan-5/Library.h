// Library.h — KHAI BAO lop Library theo so do UML o Bai 5.2.
#ifndef LIBRARY_H
#define LIBRARY_H

#include <string>
#include "Document.h"

// TODO 1: khai bao lop Library (nho dau ; sau dau } dong lop)
// TODO 2: cac thuoc tinh private dung nhu so do; items la mang con tro Document*
// TODO 3: constructor, destructor ~Library() va cac phuong thuc public (chi nguyen mau)

#endif
