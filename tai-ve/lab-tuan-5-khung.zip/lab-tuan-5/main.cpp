// main.cpp — kich ban tuan 5. File nay THAY main.cpp cua tuan 4.
#include "Document.h"
#include "Library.h"
#include <iostream>
using namespace std;

int main() {
    // TODO 1: tao thu vien "Thu vien Khoa", dia chi "Nha I - Lau 1", suc chua 5
    // TODO 2: them 3 tai lieu bang new: TL001 (2 ban), TL002 (1 ban), TL003 (3 ban)
    // TODO 3: listAll()
    // TODO 4: in "--- MUON TRA ---"; muon TL001 ba lan, muon TL999 mot lan, tra TL001 mot lan
    // TODO 5: in "--- THU SUA DU LIEU ---"; setYear(2030) roi setYear(2020) tren TL002, in lai TL002
    // TODO 6: listAll() lan nua

    return 0;
}
