// Library.cpp — CAI DAT cac ham cua Library.
#include "Library.h"
#include <iostream>
using namespace std;

// TODO 1: constructor: gan cac thuoc tinh, count bat dau bang 0, cap phat mang con tro items
// TODO 2: destructor: delete tung tai lieu, roi delete[] items, roi in dong thong bao dong cua
// TODO 3: add, findById, lend (du ba tinh huong), receive, listAll
