// main.cpp — kich ban BAI VE NHA tuan 5. Dung nguyen file nay, khong sua dong nao.
#include "Document.h"
#include "Library.h"
#include <iostream>
using namespace std;

int main() {
    Library lib("Thu vien Khoa", "Nha I - Lau 1", 2);

    cout << "--- NHAP KHO ---" << endl;
    lib.add(new Document("TL001", "Lap trinh huong doi tuong", 2019, 2));
    lib.add(new Document("TL002", "Vat ly dai cuong 1", 2021, 1));
    lib.add(new Document("TL003", "Giai tich 2", 2018, 3));          // kho day: 2 -> 4
    lib.add(new Document("TL004", "Hoa hoc dai cuong", 2020, 1));
    lib.add(new Document("TL005", "Xac suat thong ke", 2022, 2));    // kho day: 4 -> 8
    lib.listAll();

    cout << "--- GO TAI LIEU ---" << endl;
    lib.remove("TL002");            // o giua
    lib.remove("TL001");            // o dau
    lib.remove("TL005");            // o cuoi
    if (!lib.remove("TL999"))       // khong co ma nay
        cout << "(remove tra ve false)" << endl;
    lib.listAll();

    cout << "--- MUON SAU KHI GO ---" << endl;
    lib.lend("TL004");
    lib.lend("TL002");              // ma da go
    lib.listAll();
    return 0;
}
