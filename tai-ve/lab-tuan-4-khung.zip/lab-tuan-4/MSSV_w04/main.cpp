// main.cpp — DUNG hai lop Document va Reader.
#include "Document.h"
#include "Reader.h"
#include <iostream>
using namespace std;

int main() {
    // TODO 1 (Bai 4.1): tao 2 tai lieu bang constructor co tham so, 1 tai lieu bang constructor mac dinh
    // TODO 2 (Bai 4.1): in "--- DANH MUC TAI LIEU ---" roi goi display() cho ca ba tai lieu
    // TODO 3 (Bai 4.2): tao 1 ban doc, in "--- BAN DOC ---" roi goi display()

    return 0;
}
