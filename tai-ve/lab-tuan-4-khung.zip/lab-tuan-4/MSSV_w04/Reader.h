// Reader.h — KHAI BAO lop Reader. Ve so do UML o Bai 4.2 TRUOC, roi dich so do do vao day.
#ifndef READER_H
#define READER_H

#include <string>

// TODO 1: khai bao lop Reader (nho dau ; sau dau } dong lop)
// TODO 2: cac thuoc tinh public, dung nhu tang 2 cua so do ban ve
// TODO 3: constructor mac dinh, constructor nhan ma the + ho ten, ham display (chi nguyen mau)

#endif
