// Document.h — KHAI BAO lop Document. Dich tung dong cua so do UML o Bai 4.1 vao day.
#ifndef DOCUMENT_H
#define DOCUMENT_H

#include <string>

// TODO 1: khai bao lop Document (nho dau ; sau dau } dong lop)
// TODO 2: tang 2 cua UML -> ba thuoc tinh public (trong file .h dung std::string)
// TODO 3: tang 3 cua UML -> hai constructor va ham display (chi nguyen mau, khong viet than ham)

#endif
