// Reader.cpp — CAI DAT cac ham da khai bao trong Reader.h.
#include "Reader.h"
#include <iostream>
using namespace std;

// TODO 1: constructor mac dinh, dung danh sach khoi tao
// TODO 2: constructor nhan ma the + ho ten; so tai lieu dang muon luon bat dau bang 0
// TODO 3: Reader::display() in mot dong dung dinh dang ket qua mong doi
