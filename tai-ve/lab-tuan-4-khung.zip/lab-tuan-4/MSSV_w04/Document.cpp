// Document.cpp — CAI DAT cac ham da khai bao trong Document.h.
#include "Document.h"
#include <iostream>
using namespace std;

// TODO 1: constructor mac dinh, dung danh sach khoi tao voi ba gia tri de bai cho
// TODO 2: constructor co tham so, dung danh sach khoi tao (mau co san trong de)
// TODO 3: Document::display() in mot dong dung dinh dang ket qua mong doi
