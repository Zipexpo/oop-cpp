// main.cpp — kich ban tuan 9. File nay THAY main.cpp cua tuan 8.
#include "Library.h"
#include "Book.h"
#include "Magazine.h"
#include "Disc.h"
#include "Thesis.h"
#include "Renewable.h"
#include <iostream>
using namespace std;

int main() {
    // TODO 0 (9.1, thu nghiem): them dong  Document* d = new Document("TL009", "Bao cao", 2023, 1);
    //        bien dich, chep nguyen thong bao loi vao nhan_xet.txt, roi comment dong do lai

    // TODO 1: tao Library "Thu vien Khoa" voi bon tai lieu S001, TC001, D001, LV001 theo ket qua mong doi; listAll()
    // TODO 2 (9.1): voi tung ma, in loai (typeName) va han muon (loanDays)
    // TODO 3 (9.3): voi tung ma, dynamic_cast sang Renewable*; nullptr thi in "khong gia han duoc",
    //        con lai in so lan con lai, goi renew(7), roi in lai so lan con lai

    return 0;
}
