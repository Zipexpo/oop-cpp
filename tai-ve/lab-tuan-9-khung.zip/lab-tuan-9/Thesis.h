// Thesis.h — KHAI BAO lop Thesis (luan van), loai tai lieu thu tu (Bai 9.2, 9.3).
#ifndef THESIS_H
#define THESIS_H

#include "Document.h"
#include "Renewable.h"

// TODO 1 (9.2): lop Thesis ke thua PUBLIC tu Document; hai thuoc tinh private supervisor, major (chuoi)
// TODO 2 (9.2): constructor Thesis(id, title, year, copies, supervisor, major); display, loanDays, typeName co override
// TODO 3 (9.3): ke thua them PUBLIC tu Renewable; mot thuoc tinh dem so lan da gia han; renew, renewLeft co override

#endif
