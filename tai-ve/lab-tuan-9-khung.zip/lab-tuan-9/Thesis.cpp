// Thesis.cpp — CAI DAT cac ham cua Thesis.
#include "Thesis.h"
#include <iostream>
using namespace std;

// TODO 1: constructor goi constructor Document truoc; so lan da gia han bat dau bang 0
// TODO 2: display in dung dong [LUAN VAN] trong ket qua mong doi; loanDays tra 7; typeName tra "Luan van"
// TODO 3: renew: luan van chi gia han duoc 1 lan; gia han duoc thi in dong gia han nhu ket qua mong doi
