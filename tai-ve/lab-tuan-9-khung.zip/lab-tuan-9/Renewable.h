// Renewable.h — GIAO DIEN cho tai lieu gia han duoc (Bai 9.3). File nay da day du, khong can sua.
#ifndef RENEWABLE_H
#define RENEWABLE_H

// chi co ham thuan ao, khong co du lieu
class Renewable {
public:
    virtual bool renew(int days) = 0;
    virtual int  renewLeft() const = 0;
    virtual ~Renewable() = default;
};

#endif
