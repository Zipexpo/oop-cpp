// LibraryError.h — NGOAI LE RIENG cua thu vien (Bai 10.2).
#ifndef LIBRARYERROR_H
#define LIBRARYERROR_H

#include <stdexcept>
#include <string>

// TODO: lop OutOfCopies ke thua PUBLIC tu std::runtime_error.
//       Constructor nhan tua de, chuyen len runtime_error chuoi "Het ban tren ke: " + tua de.

#endif
