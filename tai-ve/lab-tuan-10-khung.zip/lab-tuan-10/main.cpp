// main.cpp — kich ban tuan 10. File nay THAY main.cpp cua tuan 9.
#include "Library.h"
#include "LibraryError.h"
#include "Book.h"
#include "Magazine.h"
#include "Disc.h"
#include "Thesis.h"
#include "StudentReader.h"
#include "LoanSlip.h"
#include <iostream>
#include <vector>
#include <stdexcept>
using namespace std;

int main() {
    // TODO 1: tao Library "Thu vien Khoa" voi kho cua de: S001 1 ban, S002 1 ban, TC001 4 ban, D001 1 ban, LV001 1 ban

    // TODO 2 (10.1): trong try, doi nam cua S001 thanh 2030; catch invalid_argument va in dung dong cua de

    // TODO 3 (10.2 - 10.4): StudentReader Tran Thi Binh, LoanDate 28/12/2026, vector<LoanSlip>, int dangMuon = 0;
    //        duyet danh sach yeu cau duoi day, moi yeu cau mot try va bon catch theo thu tu cua de
    const char* yeuCau[] = {"S001", "D001", "D001", "S999", "TC001", "LV001", "S002", "TC001"};

    // TODO 4: in cac phieu da lap
    // TODO 5: trong try, tra ma XX999; catch exception va in dung dong cua de
    // TODO 6: in dong "Chuong trinh ket thuc binh thuong."

    return 0;
}
