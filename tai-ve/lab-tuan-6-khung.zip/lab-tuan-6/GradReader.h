// GradReader.h — KHAI BAO lop GradReader, tang 3 cua chuoi ke thua (Bai 6.2).
#ifndef GRADREADER_H
#define GRADREADER_H

#include "StudentReader.h"

// TODO 1: khai bao lop GradReader ke thua PUBLIC tu StudentReader
// TODO 2: thuoc tinh private researchField (chuoi)
// TODO 3: constructor GradReader(id, fullName, studentId, faculty, researchField), maxBorrow() const, display() const

#endif
