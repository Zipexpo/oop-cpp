// main.cpp — kich ban tuan 6. File nay THAY main.cpp cua tuan 5.
#include "Book.h"
#include "Magazine.h"
#include "Reader.h"
#include "StudentReader.h"
#include "GradReader.h"
#include <iostream>
using namespace std;

int main() {
    // TODO 1: in "--- 6.1 KE THUA DON ---"; tao mot Book, mot Magazine theo ket qua mong doi; goi display()
    // TODO 2: in "--- 6.2 KE THUA DA CAP (3 tang constructor) ---"; tao Reader, StudentReader, GradReader; goi display()
    // TODO 3: in "--- 6.3 QUAN SAT: goi qua con tro lop cha ---"; cho Document* p tro toi Book o TODO 1; p->display();

    return 0;
}
