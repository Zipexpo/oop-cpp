#include "Newspaper.h"
#include <iostream>
using namespace std;

// TODO 1: constructor. Bat buoc goi constructor lop cha o DANH SACH KHOI TAO:
//     : Document(id, title, year, copies), publishDay(publishDay) {}
//   Quen goi lop cha thi bon thuoc tinh kia nhan gia tri mac dinh, cac bo kiem thu rot het.

// TODO 2: getPublishDay() const — tra ve publishDay

// TODO 3: display() const — in DUNG MOT dong, dung dinh dang sau:
//   [BAO] <id> | <title> | Ra ngay <publishDay> | Con <copies> ban
