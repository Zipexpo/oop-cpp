// Magazine.cpp — CAI DAT cac ham cua Magazine.
#include "Magazine.h"
#include <iostream>
using namespace std;

// TODO 1: constructor: goi constructor Document truoc, roi toi issueNo va month
// TODO 2: display() in dung dinh dang dong [TAP CHI] trong ket qua mong doi
