// Book.cpp — CAI DAT cac ham cua Book.
#include "Book.h"
#include <iostream>
using namespace std;

// TODO 1: constructor: goi constructor Document o DAU danh sach khoi tao, roi toi author va pages
// TODO 2: display() in dung dinh dang dong [SACH] trong ket qua mong doi
