// Magazine.h — KHAI BAO lop Magazine, lop con cua Document (Bai 6.1).
#ifndef MAGAZINE_H
#define MAGAZINE_H

#include "Document.h"

// TODO 1: khai bao lop Magazine ke thua PUBLIC tu Document
// TODO 2: hai thuoc tinh private: issueNo, month (so nguyen)
// TODO 3: constructor Magazine(id, title, year, copies, issueNo, month) va display() const

#endif
