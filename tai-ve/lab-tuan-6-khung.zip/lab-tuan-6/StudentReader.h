// StudentReader.h — KHAI BAO lop StudentReader, tang 2 cua chuoi Reader -> StudentReader -> GradReader (Bai 6.2).
#ifndef STUDENTREADER_H
#define STUDENTREADER_H

#include "Reader.h"

// TODO 1: khai bao lop StudentReader ke thua PUBLIC tu Reader
// TODO 2: hai thuoc tinh studentId, faculty (chuoi). GradReader se can dung chung: chon private hay protected?
// TODO 3: constructor StudentReader(id, fullName, studentId, faculty), maxBorrow() const, display() const

#endif
