// Book.h — KHAI BAO lop Book, lop con cua Document (Bai 6.1).
#ifndef BOOK_H
#define BOOK_H

#include "Document.h"

// TODO 1: khai bao lop Book ke thua PUBLIC tu Document
// TODO 2: hai thuoc tinh private: author (chuoi), pages (so nguyen)
// TODO 3: constructor Book(id, title, year, copies, author, pages) va display() const

#endif
