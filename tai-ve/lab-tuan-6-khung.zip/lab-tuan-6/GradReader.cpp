// GradReader.cpp — CAI DAT cac ham cua GradReader.
#include "GradReader.h"
#include <iostream>
using namespace std;

// TODO 1: constructor: goi constructor cua lop cha TRUC TIEP (StudentReader), roi toi researchField
// TODO 2: maxBorrow() tra ve 10
// TODO 3: display() in dung dinh dang dong [CAO HOC] trong ket qua mong doi
