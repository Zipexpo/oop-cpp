// StudentReader.cpp — CAI DAT cac ham cua StudentReader.
#include "StudentReader.h"
#include <iostream>
using namespace std;

// TODO 1: constructor: goi constructor Reader truoc, roi toi studentId va faculty
// TODO 2: maxBorrow() tra ve 5
// TODO 3: display() in dung dinh dang dong [SINH VIEN] trong ket qua mong doi
