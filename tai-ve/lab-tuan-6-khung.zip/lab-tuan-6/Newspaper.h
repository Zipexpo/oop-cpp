// Newspaper.h — bai ve nha tuan 6. Lam trong ... phut  <-- ghi so phut ban mat vao day.
#ifndef NEWSPAPER_H
#define NEWSPAPER_H

#include "Document.h"

// Newspaper "la mot" Document, co them ngay ra bao.
// Ba chu ky duoi day la hop dong voi may cham: giu nguyen y nguyen, ke ca chu const o cuoi.
class Newspaper : public Document {
private:
    std::string publishDay;    // dang dd/mm/yyyy, vi du "16/10/2026"

public:
    Newspaper(const std::string& id, const std::string& title, int year, int copies,
              const std::string& publishDay);

    std::string getPublishDay() const;
    void display() const;
};

#endif
