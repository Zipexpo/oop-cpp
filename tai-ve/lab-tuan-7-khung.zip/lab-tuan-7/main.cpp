// main.cpp — kich ban tuan 7. File nay THAY main.cpp cua tuan 6.
#include "Document.h"
#include "Book.h"
#include "Magazine.h"
#include "Reader.h"
#include "StudentReader.h"
#include "GradReader.h"
#include "LoanDate.h"
#include <iostream>
using namespace std;

int main() {
    // TODO 1 (7.1): in dong tieu de; mang Document* ds[3] gom mot Book, mot Magazine, mot Document tao bang new; goi display()
    // TODO 2 (7.2): LoanDate today(28, 12, 2026); moi tai lieu in ngay muon va han tra = today + ds[i]->loanDays()
    // TODO 3 (7.3): hai moc 20/12/2026 va 05/01/2027; in so ngay giu bang phep tru hai LoanDate
    // TODO 4 (7.4): mang Reader* rs[3] gom Reader, StudentReader, GradReader tao bang new; goi display()
    // TODO 5 (7.5): in dong tieu de; delete ba tai lieu roi delete ba ban doc

    return 0;
}
