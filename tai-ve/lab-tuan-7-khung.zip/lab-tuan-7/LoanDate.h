// LoanDate.h — KHAI BAO lop LoanDate theo so do UML o Bai 7.3.
#ifndef LOANDATE_H
#define LOANDATE_H

#include <iostream>

// TODO 1: khai bao lop LoanDate voi ba thuoc tinh private: day, month, year
// TODO 2: ba ham phu private: isLeap(y), daysInMonth(m, y), nextDay()
// TODO 3: constructor mac dinh, constructor (d, m, y), destructor
// TODO 4: operator+(int days) const tra ve LoanDate; operator-(const LoanDate& other) const tra ve int
// TODO 5: friend operator<< nhan std::ostream& va const LoanDate&, tra ve std::ostream&

#endif
