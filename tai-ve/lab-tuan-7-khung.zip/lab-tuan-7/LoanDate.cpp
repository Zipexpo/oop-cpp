// LoanDate.cpp — CAI DAT cac ham cua LoanDate.
#include "LoanDate.h"
using namespace std;

// TODO 1: isLeap: chia het cho 4 nhung khong chia het cho 100, hoac chia het cho 400
// TODO 2: daysInMonth: so ngay cua thang m trong nam y; thang 2 nam nhuan co 29 ngay
// TODO 3: nextDay: tien mot ngay, tu sang thang moi, sang nam moi
// TODO 4: operator+ tra ve mot doi tuong MOI, khong sua doi tuong goc; operator- dem so ngay giua hai moc
// TODO 5: operator<< in dang dd/mm/yyyy, them so 0 o dau khi can, cuoi cung tra ve os
